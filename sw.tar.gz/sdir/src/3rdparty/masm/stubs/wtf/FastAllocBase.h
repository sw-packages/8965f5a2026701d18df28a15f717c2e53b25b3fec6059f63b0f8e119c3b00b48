// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
#ifndef FASTALLOCBASE_H
#define FASTALLOCBASE_H

/* Dummy empty header file, only needed for #include source compatibility */

#define WTF_MAKE_FAST_ALLOCATED

#endif // FASTALLOCBASE_H
